#ifndef _REJECTIONBOUNDARY_H_
#define _REJECTIONBOUNDARY_H_

#define BOUNDARY_LEN 2048
extern double rejectionBoundary[BOUNDARY_LEN];
extern double rejectionBoundary6[BOUNDARY_LEN];
    
#endif
